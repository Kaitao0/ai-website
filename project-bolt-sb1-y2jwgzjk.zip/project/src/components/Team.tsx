import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Linkedin, Twitter, Mail } from 'lucide-react';

const team = [
  {
    name: 'Elena Romano',
    role: 'CEO & AI Strategist',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400',
    social: {
      linkedin: '#',
      twitter: '#',
      email: 'elena@example.com',
    },
  },
  {
    name: 'Marco Bianchi',
    role: 'CTO & Lead Developer',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400',
    social: {
      linkedin: '#',
      twitter: '#',
      email: 'marco@example.com',
    },
  },
  {
    name: 'Sofia Conti',
    role: 'Head of AI Research',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=400',
    social: {
      linkedin: '#',
      twitter: '#',
      email: 'sofia@example.com',
    },
  },
  {
    name: 'Luca Ferrari',
    role: 'UX Designer',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=400',
    social: {
      linkedin: '#',
      twitter: '#',
      email: 'luca@example.com',
    },
  },
];

export const Team = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section className="py-20 bg-gray-900" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Our Team</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Meet the experts behind our AI innovation, bringing together technology and creativity.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {team.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="card group"
            >
              <div className="relative mb-6 overflow-hidden rounded-lg aspect-square">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-4 flex justify-center space-x-4 opacity-0 group-hover:opacity-100 transform translate-y-full group-hover:translate-y-0 transition-all duration-300">
                  <a href={member.social.linkedin} className="text-white hover:text-blue-400">
                    <Linkedin className="w-5 h-5" />
                  </a>
                  <a href={member.social.twitter} className="text-white hover:text-blue-400">
                    <Twitter className="w-5 h-5" />
                  </a>
                  <a href={`mailto:${member.social.email}`} className="text-white hover:text-blue-400">
                    <Mail className="w-5 h-5" />
                  </a>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-2">{member.name}</h3>
              <p className="text-blue-400">{member.role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};