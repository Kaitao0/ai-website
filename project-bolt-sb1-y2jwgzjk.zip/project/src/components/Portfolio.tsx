import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Users, TrendingUp, Clock, MessageSquareHeart } from 'lucide-react';

const cases = [
  {
    title: 'E-commerce Support Revolution',
    image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80&w=1200',
    metrics: [
      { icon: Users, value: '500K+', label: 'Users Served' },
      { icon: TrendingUp, value: '85%', label: 'Resolution Rate' },
      { icon: Clock, value: '24/7', label: 'Availability' },
      { icon: MessageSquareHeart, value: '95%', label: 'Satisfaction' },
    ],
    description: 'Transformed customer support for a major e-commerce platform with AI-powered chat assistance.',
  },
  {
    title: 'Banking Service Enhancement',
    image: 'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?auto=format&fit=crop&q=80&w=1200',
    metrics: [
      { icon: Users, value: '1M+', label: 'Customers' },
      { icon: TrendingUp, value: '90%', label: 'Query Resolution' },
      { icon: Clock, value: '-60%', label: 'Response Time' },
      { icon: MessageSquareHeart, value: '98%', label: 'Satisfaction' },
    ],
    description: 'Implemented an AI chatbot for a leading bank, handling customer queries and transactions.',
  },
];

export const Portfolio = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section className="py-20 bg-gray-900" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Success Stories</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Discover how our AI chatbots have transformed businesses and improved customer experiences.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {cases.map((caseStudy, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="card overflow-hidden group"
            >
              <div className="relative h-48 mb-6 overflow-hidden rounded-lg">
                <img
                  src={caseStudy.image}
                  alt={caseStudy.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent" />
              </div>
              <h3 className="text-2xl font-bold mb-4">{caseStudy.title}</h3>
              <p className="text-gray-400 mb-6">{caseStudy.description}</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {caseStudy.metrics.map((metric, idx) => (
                  <div key={idx} className="text-center">
                    <metric.icon className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                    <div className="text-xl font-bold text-blue-400">{metric.value}</div>
                    <div className="text-sm text-gray-400">{metric.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};