import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Bot, User } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'bot' | 'user';
}

export const DemoModal = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentStep, setCurrentStep] = useState(0);

  const demoConversation = [
    { sender: 'bot', text: "Hi! I'm Iaky, your AI assistant. How can I help you today?" },
    { sender: 'user', text: "I'm interested in implementing a chatbot for my e-commerce website." },
    { sender: 'bot', text: "Great choice! Our e-commerce chatbot can help with customer support, order tracking, and product recommendations. Would you like to know more about these features?" },
    { sender: 'user', text: "Yes, please tell me about the customer support capabilities." },
    { sender: 'bot', text: "Our chatbot can handle common customer queries 24/7, including:\n- Order status updates\n- Return requests\n- Product information\n- Shipping details\n- Payment issues\nThis typically reduces customer service costs by 30% and improves response times significantly." },
    { sender: 'user', text: "That sounds promising. What about integration time?" },
    { sender: 'bot', text: "Integration is quick and seamless! Most clients are up and running within 48 hours. We provide full technical support and documentation. Would you like to schedule a detailed demo with our team?" }
  ];

  useEffect(() => {
    if (isOpen && currentStep < demoConversation.length) {
      const timer = setTimeout(() => {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          ...demoConversation[currentStep]
        }]);
        setCurrentStep(prev => prev + 1);
      }, currentStep === 0 ? 500 : 1000);

      return () => clearTimeout(timer);
    }
  }, [isOpen, currentStep]);

  // Access this function via window.openDemoModal
  useEffect(() => {
    (window as any).openDemoModal = () => setIsOpen(true);
    return () => {
      delete (window as any).openDemoModal;
    };
  }, []);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-gray-900 rounded-xl shadow-2xl w-full max-w-lg"
          >
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Bot className="w-6 h-6 text-blue-500" />
                <h3 className="text-lg font-semibold">Iaky Demo</h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 h-96 overflow-y-auto space-y-4">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex items-start gap-2 ${
                    message.sender === 'user' ? 'flex-row-reverse' : ''
                  }`}
                >
                  {message.sender === 'bot' ? (
                    <Bot className="w-6 h-6 text-blue-500" />
                  ) : (
                    <User className="w-6 h-6 text-gray-400" />
                  )}
                  <div
                    className={`rounded-lg p-3 max-w-[80%] ${
                      message.sender === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-800 text-gray-100'
                    }`}
                  >
                    {message.text}
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="p-4 border-t border-gray-800">
              <button
                onClick={() => {
                  setMessages([]);
                  setCurrentStep(0);
                }}
                className="btn btn-primary w-full"
              >
                Restart Demo
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};