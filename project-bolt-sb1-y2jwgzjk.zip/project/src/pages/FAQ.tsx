import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ChevronDown, ChevronUp } from 'lucide-react';

export const FAQ = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      category: 'General',
      questions: [
        {
          q: 'What is Iaky?',
          a: 'Iaky is an advanced AI chatbot platform that helps businesses automate customer interactions using natural language processing and machine learning technologies.',
        },
        {
          q: 'How can Iaky benefit my business?',
          a: 'Iaky can help reduce customer service costs, provide 24/7 support, increase customer satisfaction, and gather valuable insights from customer interactions.',
        },
        {
          q: 'Is Iaky difficult to set up?',
          a: 'Not at all! Iaky can be integrated into your website or application with just a few lines of code. We provide comprehensive documentation and support to help you get started.',
        },
      ],
    },
    {
      category: 'Technical',
      questions: [
        {
          q: 'What platforms does Iaky support?',
          a: 'Iaky supports web, mobile, and popular messaging platforms like WhatsApp, Facebook Messenger, and Slack.',
        },
        {
          q: "Can I customize Iaky's responses?",
          a: "Yes, you can fully customize Iaky's responses, personality, and knowledge base to match your brand voice and specific needs.",
        },
        {
          q: 'How secure is Iaky?',
          a: 'Iaky uses bank-grade encryption and complies with GDPR, CCPA, and other international data protection standards.',
        },
      ],
    },
    {
      category: 'Pricing & Support',
      questions: [
        {
          q: 'What pricing plans are available?',
          a: 'We offer flexible pricing plans starting from $29/month for small businesses to custom enterprise solutions. All plans come with a 14-day free trial.',
        },
        {
          q: 'What kind of support do you offer?',
          a: 'We provide email support for all plans, with priority support and dedicated account managers for higher-tier plans.',
        },
        {
          q: 'Can I upgrade or downgrade my plan?',
          a: 'Yes, you can change your plan at any time. Changes will be reflected in your next billing cycle.',
        },
      ],
    },
  ];

  return (
    <div className="pt-20 min-h-screen">
      <section className="py-20 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Frequently Asked
              <span className="gradient-text block">Questions</span>
            </h1>
            <p className="text-xl text-gray-400">
              Find answers to common questions about Iaky and our services.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20" ref={ref}>
        <div className="container mx-auto px-4">
          {faqs.map((category, categoryIndex) => (
            <motion.div
              key={categoryIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: categoryIndex * 0.2 }}
              className="mb-12"
            >
              <h2 className="text-2xl font-bold mb-6">{category.category}</h2>
              <div className="space-y-4">
                {category.questions.map((faq, faqIndex) => {
                  const index = categoryIndex * 100 + faqIndex;
                  const isOpen = openIndex === index;

                  return (
                    <div
                      key={faqIndex}
                      className="card cursor-pointer hover:border-blue-500 transition-colors duration-300"
                      onClick={() => setOpenIndex(isOpen ? null : index)}
                    >
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-semibold">{faq.q}</h3>
                        {isOpen ? (
                          <ChevronUp className="w-5 h-5 text-blue-500" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-blue-500" />
                        )}
                      </div>
                      <motion.div
                        initial={false}
                        animate={{ height: isOpen ? 'auto' : 0 }}
                        className="overflow-hidden"
                      >
                        {isOpen && (
                          <p className="mt-4 text-gray-400">{faq.a}</p>
                        )}
                      </motion.div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};