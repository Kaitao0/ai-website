import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CreditCard, Lock, CheckCircle } from 'lucide-react';

export const Checkout = () => {
  const { plan } = useParams();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    email: '',
    cardName: '',
    cardNumber: '',
    expiry: '',
    cvc: '',
  });

  const plans = {
    starter: {
      name: 'Starter',
      price: 29,
      features: [
        'Up to 1,000 conversations/month',
        'Basic AI responses',
        'Email support',
        'Widget customization',
      ],
    },
    professional: {
      name: 'Professional',
      price: 99,
      features: [
        'Up to 10,000 conversations/month',
        'Advanced AI with context awareness',
        'Priority support',
        'Full customization options',
        'API access',
      ],
    },
    enterprise: {
      name: 'Enterprise',
      price: 299,
      features: [
        'Unlimited conversations',
        'Custom AI model training',
        '24/7 dedicated support',
        'Full white-labeling',
        'Custom integrations',
      ],
    },
  };

  const selectedPlan = plans[plan as keyof typeof plans];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
    // Simulate processing
    setTimeout(() => {
      setStep(3);
    }, 2000);
  };

  return (
    <div className="pt-20 min-h-screen bg-gray-900">
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mx-auto"
        >
          {step === 1 && (
            <div className="card">
              <div className="flex items-center justify-between mb-8">
                <h1 className="text-2xl font-bold">Checkout</h1>
                <Lock className="text-blue-500 w-6 h-6" />
              </div>

              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
                <div className="card bg-gray-800/50">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-lg">{selectedPlan.name} Plan</span>
                    <span className="text-2xl font-bold">${selectedPlan.price}/mo</span>
                  </div>
                  <ul className="space-y-2">
                    {selectedPlan.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-gray-400">
                        <CheckCircle className="w-4 h-4 text-blue-500 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 focus:border-blue-500 focus:ring focus:ring-blue-500/20"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Name on Card
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.cardName}
                    onChange={(e) => setFormData({ ...formData, cardName: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 focus:border-blue-500 focus:ring focus:ring-blue-500/20"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Card Number
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={formData.cardNumber}
                      onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
                      className="w-full px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 focus:border-blue-500 focus:ring focus:ring-blue-500/20"
                    />
                    <CreditCard className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      Expiry Date
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="MM/YY"
                      value={formData.expiry}
                      onChange={(e) => setFormData({ ...formData, expiry: e.target.value })}
                      className="w-full px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 focus:border-blue-500 focus:ring focus:ring-blue-500/20"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      CVC
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.cvc}
                      onChange={(e) => setFormData({ ...formData, cvc: e.target.value })}
                      className="w-full px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 focus:border-blue-500 focus:ring focus:ring-blue-500/20"
                    />
                  </div>
                </div>

                <button type="submit" className="btn btn-primary w-full">
                  Pay ${selectedPlan.price}/month
                </button>
              </form>
            </div>
          )}

          {step === 2 && (
            <div className="card text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
              <h2 className="text-xl font-semibold">Processing your payment...</h2>
              <p className="text-gray-400 mt-2">Please don't close this window.</p>
            </div>
          )}

          {step === 3 && (
            <div className="card text-center">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold mb-4">Payment Successful!</h2>
              <p className="text-gray-400 mb-6">
                Thank you for choosing Prime AI Solutions. You'll receive a confirmation email shortly.
              </p>
              <button
                onClick={() => navigate('/')}
                className="btn btn-primary"
              >
                Return to Homepage
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};