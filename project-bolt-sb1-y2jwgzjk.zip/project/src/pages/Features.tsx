import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Bot, Zap, Shield, Cpu, Globe, Gauge, MessageSquare, Code } from 'lucide-react';

export const Features = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const features = [
    {
      icon: Bot,
      title: 'Advanced AI Understanding',
      description: 'Natural language processing that understands context and intent for more meaningful conversations.',
    },
    {
      icon: Zap,
      title: 'Lightning Fast Responses',
      description: 'Optimized response times with our distributed infrastructure for instant customer support.',
    },
    {
      icon: Shield,
      title: 'Enterprise Security',
      description: 'Bank-grade encryption and compliance with international data protection standards.',
    },
    {
      icon: Cpu,
      title: 'Machine Learning',
      description: 'Continuous learning from interactions to improve response accuracy over time.',
    },
    {
      icon: Globe,
      title: 'Multilingual Support',
      description: 'Support for over 50 languages with real-time translation capabilities.',
    },
    {
      icon: Gauge,
      title: 'Analytics Dashboard',
      description: 'Comprehensive analytics and insights to track and improve performance.',
    },
    {
      icon: MessageSquare,
      title: 'Omnichannel Integration',
      description: 'Seamless integration with popular messaging platforms and social media.',
    },
    {
      icon: Code,
      title: 'Developer API',
      description: 'Robust API for custom integrations and advanced functionality.',
    },
  ];

  return (
    <div className="pt-20 min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Powerful Features for
              <span className="gradient-text block">Modern Businesses</span>
            </h1>
            <p className="text-xl text-gray-400 mb-8">
              Discover how Iaky can transform your customer interactions with cutting-edge AI technology.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20" ref={ref}>
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="card hover-glow group cursor-pointer"
              >
                <feature.icon className="w-12 h-12 text-blue-500 mb-4 transform group-hover:scale-110 transition-transform duration-300" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Integration Section */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">Easy Integration</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Connect Iaky with your favorite platforms in minutes. No complex setup required.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
            >
              <pre className="bg-gray-900 p-6 rounded-lg overflow-x-auto">
                <code className="text-blue-400">
                  {`// Initialize Iaky
const iaky = new IakyAI({
  apiKey: 'your-api-key',
  model: 'enterprise-v2'
});

// Start listening
iaky.listen({
  channel: 'website',
  onMessage: (msg) => {
    console.log('New message:', msg);
  }
});`}
                </code>
              </pre>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <div className="card">
                <h3 className="text-xl font-semibold mb-2">Simple API</h3>
                <p className="text-gray-400">
                  Our well-documented API makes integration a breeze. Get started with just a few lines of code.
                </p>
              </div>
              <div className="card">
                <h3 className="text-xl font-semibold mb-2">Flexible Configuration</h3>
                <p className="text-gray-400">
                  Customize Iaky's behavior and appearance to match your brand and requirements.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};