import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Calendar, User, Tag } from 'lucide-react';

export const BlogPost = () => {
  const { slug } = useParams();
  const navigate = useNavigate();

  const posts = {
    'future-of-customer-service': {
      title: 'The Future of Customer Service: AI-Powered Chatbots',
      image: 'https://images.unsplash.com/photo-1531746790731-6c087fecd65a?auto=format&fit=crop&q=80&w=1200',
      author: 'Elena Romano',
      date: '2024-03-15',
      category: 'Technology',
      content: `
        <h2>The Evolution of Customer Service</h2>
        <p>The customer service landscape is rapidly evolving, with AI-powered chatbots leading the charge in transforming how businesses interact with their customers. This shift represents more than just a technological advancement; it's a fundamental change in the way we think about customer support.</p>

        <h2>Why Chatbots Are Revolutionary</h2>
        <p>AI chatbots are revolutionizing customer service in several key ways:</p>
        <ul>
          <li>24/7 Availability: Unlike human agents, chatbots can provide instant support at any time</li>
          <li>Scalability: Handle thousands of conversations simultaneously</li>
          <li>Consistency: Deliver uniform responses and maintain service quality</li>
          <li>Cost-Effectiveness: Reduce operational costs while improving service delivery</li>
        </ul>

        <h2>The Technology Behind Modern Chatbots</h2>
        <p>Modern AI chatbots leverage advanced technologies including:</p>
        <ul>
          <li>Natural Language Processing (NLP)</li>
          <li>Machine Learning</li>
          <li>Sentiment Analysis</li>
          <li>Context Understanding</li>
        </ul>

        <h2>Real-World Impact</h2>
        <p>Businesses implementing AI chatbots have reported:</p>
        <ul>
          <li>40% reduction in customer service costs</li>
          <li>70% improvement in response times</li>
          <li>85% customer satisfaction rates</li>
          <li>Significant increase in customer engagement</li>
        </ul>

        <h2>The Future Outlook</h2>
        <p>As AI technology continues to advance, we can expect to see even more sophisticated chatbot capabilities, including:</p>
        <ul>
          <li>Enhanced emotional intelligence</li>
          <li>Better context awareness</li>
          <li>More natural conversations</li>
          <li>Deeper integration with business systems</li>
        </ul>
      `,
    },
    'choosing-right-chatbot': {
      title: 'How to Choose the Right Chatbot for Your Business',
      image: 'https://images.unsplash.com/photo-1552581234-26160f608093?auto=format&fit=crop&q=80&w=1200',
      author: 'Marco Bianchi',
      date: '2024-03-10',
      category: 'Guide',
      content: `
        <h2>Understanding Your Needs</h2>
        <p>Before selecting a chatbot solution, it's crucial to understand your specific business requirements and objectives. This guide will help you navigate the selection process effectively.</p>

        <h2>Key Factors to Consider</h2>
        <ul>
          <li>Business Size and Scale</li>
          <li>Industry-Specific Requirements</li>
          <li>Integration Capabilities</li>
          <li>Budget Constraints</li>
          <li>Technical Resources</li>
        </ul>

        <h2>Types of Chatbots</h2>
        <p>Understanding different chatbot types is crucial for making the right choice:</p>
        <ul>
          <li>Rule-Based Chatbots</li>
          <li>AI-Powered Conversational Agents</li>
          <li>Hybrid Solutions</li>
          <li>Industry-Specific Chatbots</li>
        </ul>

        <h2>Implementation Considerations</h2>
        <p>Key aspects to consider during implementation:</p>
        <ul>
          <li>Integration Timeline</li>
          <li>Training Requirements</li>
          <li>Maintenance Needs</li>
          <li>Scalability Options</li>
        </ul>

        <h2>Measuring Success</h2>
        <p>Important metrics to track:</p>
        <ul>
          <li>Response Time</li>
          <li>Resolution Rate</li>
          <li>Customer Satisfaction</li>
          <li>Cost Savings</li>
        </ul>
      `,
    },
    // Add more blog posts here
  };

  const post = posts[slug as keyof typeof posts];

  if (!post) {
    return (
      <div className="pt-20 min-h-screen bg-gray-900">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Post not found</h1>
            <button
              onClick={() => navigate('/blog')}
              className="btn btn-primary"
            >
              Return to Blog
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-900">
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <button
            onClick={() => navigate('/blog')}
            className="flex items-center text-gray-400 hover:text-white mb-8 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Blog
          </button>

          <div className="relative h-[400px] mb-8 rounded-xl overflow-hidden">
            <img
              src={post.image}
              alt={post.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent" />
          </div>

          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
            <div className="flex items-center space-x-6 text-gray-400">
              <div className="flex items-center">
                <User className="w-4 h-4 mr-2" />
                {post.author}
              </div>
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                {post.date}
              </div>
              <div className="flex items-center">
                <Tag className="w-4 h-4 mr-2" />
                {post.category}
              </div>
            </div>
          </div>

          <div className="prose prose-invert max-w-none">
            <div dangerouslySetInnerHTML={{ __html: post.content }} />
          </div>
        </motion.div>
      </div>
    </div>
  );
};