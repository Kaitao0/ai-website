import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Features } from './pages/Features';
import { Pricing } from './pages/Pricing';
import { FAQ } from './pages/FAQ';
import { Blog } from './pages/Blog';
import { Contact } from './pages/Contact';
import { ChatWidget } from './components/ChatWidget';
import { Checkout } from './pages/Checkout';
import { BlogPost } from './pages/BlogPost';
import { DemoModal } from './components/DemoModal';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black/[0.96] flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/features" element={<Features />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/checkout/:plan" element={<Checkout />} />
          </Routes>
        </main>
        <ChatWidget />
        <DemoModal />
        <Footer />
      </div>
    </Router>
  );
}

export default App;