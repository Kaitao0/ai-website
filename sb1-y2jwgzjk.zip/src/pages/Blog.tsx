import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Calendar, User, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Blog = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const posts = [
    {
      title: 'The Future of Customer Service: AI-Powered Chatbots',
      excerpt: 'Discover how AI is revolutionizing customer service and why businesses are rapidly adopting chatbot solutions.',
      image: 'https://images.unsplash.com/photo-1531746790731-6c087fecd65a?auto=format&fit=crop&q=80&w=1200',
      author: 'Elena Romano',
      date: '2024-03-15',
      category: 'Technology',
      slug: 'future-of-customer-service',
    },
    {
      title: 'How to Choose the Right Chatbot for Your Business',
      excerpt: 'A comprehensive guide to selecting and implementing the perfect chatbot solution for your specific needs.',
      image: 'https://images.unsplash.com/photo-1552581234-26160f608093?auto=format&fit=crop&q=80&w=1200',
      author: 'Marco Bianchi',
      date: '2024-03-10',
      category: 'Guide',
      slug: 'choosing-right-chatbot',
    },
    {
      title: 'The Role of Natural Language Processing in Modern AI',
      excerpt: 'Understanding how NLP is making AI conversations more human-like and effective.',
      image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=1200',
      author: 'Sofia Conti',
      date: '2024-03-05',
      category: 'Technology',
      slug: 'role-of-nlp',
    },
    {
      title: 'Measuring ROI: The Business Impact of AI Chatbots',
      excerpt: 'Learn how to calculate and maximize the return on investment from your chatbot implementation.',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=1200',
      author: 'Luca Ferrari',
      date: '2024-02-28',
      category: 'Business',
      slug: 'measuring-chatbot-roi',
    },
  ];

  return (
    <div className="pt-20 min-h-screen">
      <section className="py-20 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Latest Insights from
              <span className="gradient-text block">Prime AI Solutions</span>
            </h1>
            <p className="text-xl text-gray-400">
              Stay updated with the latest trends, tips, and insights in AI and chatbot technology.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20" ref={ref}>
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            {posts.map((post, index) => (
              <motion.article
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="card group cursor-pointer"
              >
                <Link to={`/blog/${post.slug}`}>
                  <div className="relative h-48 mb-6 overflow-hidden rounded-lg">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-60" />
                    <div className="absolute bottom-4 left-4">
                      <span className="px-3 py-1 bg-blue-500 text-white text-sm rounded-full">
                        {post.category}
                      </span>
                    </div>
                  </div>
                  <h2 className="text-2xl font-bold mb-3 group-hover:text-blue-400 transition-colors duration-300">
                    {post.title}
                  </h2>
                  <p className="text-gray-400 mb-4">{post.excerpt}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center text-gray-400">
                        <User className="w-4 h-4 mr-2" />
                        <span className="text-sm">{post.author}</span>
                      </div>
                      <div className="flex items-center text-gray-400">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span className="text-sm">{post.date}</span>
                      </div>
                    </div>
                    <div className="text-blue-400 group-hover:text-blue-300 transition-colors duration-300 flex items-center">
                      Read More
                      <ArrowRight className="w-4 h-4 ml-2 transform group-hover:translate-x-2 transition-transform duration-300" />
                    </div>
                  </div>
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};