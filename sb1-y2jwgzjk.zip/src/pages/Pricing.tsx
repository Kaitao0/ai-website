import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Check, Bot, Zap, Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const Pricing = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const navigate = useNavigate();

  const plans = [
    {
      name: 'Starter',
      price: 29,
      icon: Bot,
      description: 'Perfect for small businesses starting with AI',
      features: [
        'Up to 1,000 conversations/month',
        'Basic AI responses',
        'Email support',
        'Widget customization',
        'Basic analytics',
      ],
      id: 'starter',
    },
    {
      name: 'Professional',
      price: 99,
      icon: Zap,
      description: 'Ideal for growing companies',
      popular: true,
      features: [
        'Up to 10,000 conversations/month',
        'Advanced AI with context awareness',
        'Priority support',
        'Full customization options',
        'Advanced analytics',
        'API access',
        'Multiple team members',
      ],
      id: 'professional',
    },
    {
      name: 'Enterprise',
      price: 299,
      icon: Shield,
      description: 'For large organizations with complex needs',
      features: [
        'Unlimited conversations',
        'Custom AI model training',
        '24/7 dedicated support',
        'Full white-labeling',
        'Enterprise analytics',
        'Custom integrations',
        'SLA guarantee',
        'Dedicated account manager',
      ],
      id: 'enterprise',
    },
  ];

  return (
    <div className="pt-20 min-h-screen">
      <section className="py-20 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Simple, Transparent
              <span className="gradient-text block">Pricing</span>
            </h1>
            <p className="text-xl text-gray-400">
              Choose the perfect plan for your business needs. All plans include our core AI features.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8" ref={ref}>
            {plans.map((plan, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className={`card relative ${
                  plan.popular ? 'border-2 border-blue-500' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="flex items-center justify-center mb-6">
                  <plan.icon className="w-12 h-12 text-blue-500" />
                </div>

                <h3 className="text-2xl font-bold text-center mb-2">{plan.name}</h3>
                <p className="text-gray-400 text-center mb-6">{plan.description}</p>

                <div className="text-center mb-8">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-gray-400">/month</span>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="w-5 h-5 text-blue-500 mr-2" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button 
                  onClick={() => navigate(`/checkout/${plan.id}`)}
                  className="w-full btn btn-primary"
                >
                  Get Started
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="card">
              <h3 className="text-xl font-semibold mb-2">Can I change plans later?</h3>
              <p className="text-gray-400">
                Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.
              </p>
            </div>
            <div className="card">
              <h3 className="text-xl font-semibold mb-2">What happens if I exceed my limit?</h3>
              <p className="text-gray-400">
                We'll notify you when you're close to your limit. You can either upgrade your plan or pay for additional conversations.
              </p>
            </div>
            <div className="card">
              <h3 className="text-xl font-semibold mb-2">Do you offer a free trial?</h3>
              <p className="text-gray-400">
                Yes, all plans come with a 14-day free trial. No credit card required to start.
              </p>
            </div>
            <div className="card">
              <h3 className="text-xl font-semibold mb-2">What kind of support do you offer?</h3>
              <p className="text-gray-400">
                All plans include email support. Professional and Enterprise plans include priority support with faster response times.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};