import React from 'react';
import { motion } from 'framer-motion';
import { TypeAnimation } from 'react-type-animation';
import { MessageSquare, Bot, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SplineScene } from './ui/spline-scene';

export const Hero = () => {
  const navigate = useNavigate();

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Spline Scene */}
      <div className="absolute inset-0 z-0">
        <SplineScene 
          scene="https://prod.spline.design/kZDDjO5HuC9GJUM2/scene.splinecode"
          className="w-full h-full"
        />
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="backdrop-blur-sm bg-black/30 p-8 rounded-xl"
          >
            <h1 className="text-5xl lg:text-7xl font-bold mb-6">
              PrimeSystemAI
              <span className="gradient-text block">AI Solutions for your Business</span>
            </h1>
            <div className="text-xl text-gray-300 mb-8">
              <TypeAnimation
                sequence={[
                  'Enhance Customer Experience',
                  2000,
                  'Automate Support 24/7',
                  2000,
                  'Boost Engagement',
                  2000,
                ]}
                repeat={Infinity}
              />
            </div>
            <div className="flex gap-4">
              <button 
                onClick={() => navigate('/checkout/professional')}
                className="btn btn-primary"
              >
                Get Started
                <Sparkles className="inline-block ml-2 w-5 h-5" />
              </button>
              <button 
                onClick={() => (window as any).openDemoModal()}
                className="btn btn-outline"
              >
                View Demo
                <Bot className="inline-block ml-2 w-5 h-5" />
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative backdrop-blur-sm bg-black/30 rounded-xl p-6"
          >
            <div className="card p-6 bg-black/50">
              <div className="flex items-center gap-3 mb-4">
                <img src="https://pub-78d23252e3324567b5ee23d57acddddd.r2.dev/public/bmf3y2jk_.png" alt="PrimeSystemAI Logo" className="w-8 h-8" />
                <h3 className="text-xl font-semibold">AI Assistant</h3>
              </div>
              <div className="chat-window space-y-4">
                <div className="flex items-start gap-3">
                  <Bot className="w-6 h-6 mt-1 text-blue-500" />
                  <div className="bg-gray-800/50 rounded-lg p-3">
                    Hello! How can I assist you today?
                  </div>
                </div>
                <div className="flex items-start gap-3 justify-end">
                  <div className="bg-blue-600/50 rounded-lg p-3">
                    I'd like to learn more about your AI solutions.
                  </div>
                  <MessageSquare className="w-6 h-6 mt-1" />
                </div>
                <div className="flex items-start gap-3">
                  <Bot className="w-6 h-6 mt-1 text-blue-500" />
                  <div className="bg-gray-800/50 rounded-lg p-3">
                    I'd be happy to explain our solutions! We offer customizable AI systems that can be integrated into your workflow...
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};